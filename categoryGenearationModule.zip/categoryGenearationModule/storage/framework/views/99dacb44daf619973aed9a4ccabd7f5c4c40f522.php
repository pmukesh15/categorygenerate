<!DOCTYPE html>
<html>
    <head>
    </head>
    <body class="font-sans antialiased">
            <!-- Page Content -->
            <main>
                <form name="categoryAdd" method="GET" action="/save-category">
                    <input type="text" name="category" placeholder="Enter category name">
                    <button type="submit">Submit</button>
                </form>
                <br>
                <table>
                <tr>
                    <th>Name</th>
                    <th>URL</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($d->category_name); ?></td>
                    <td><?php echo e($d->category_url); ?></td>
                    <td><button type="button">edit</button></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </main>
        </div>
    </body>
</html>
<?php /**PATH /home/lilac-pc-17/Desktop/laravel7project/categoryGenearationModule/resources/views/createCategory.blade.php ENDPATH**/ ?>
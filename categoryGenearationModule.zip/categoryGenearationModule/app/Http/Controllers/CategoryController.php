<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class CategoryController extends Controller
{
    //
    public function viewCategory(){
        $data = DB::table('category')->get();
        return view('createCategory',compact('data'));
    }
    public function saveCategory(Request $request){
        $currentUrl = url("/")."/view-category/";
        DB::table('category')->insert([
            ['category_name' => $request->category, 'category_url' => $currentUrl.$request->category]
        ]);
        return redirect()->route('add-category');
    }
}

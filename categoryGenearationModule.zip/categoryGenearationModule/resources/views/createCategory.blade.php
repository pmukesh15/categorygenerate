<!DOCTYPE html>
<html>
    <head>
    </head>
    <body class="font-sans antialiased">
            <!-- Page Content -->
            <main>
                <form name="categoryAdd" method="GET" action="/save-category">
                    <input type="text" name="category" placeholder="Enter category name">
                    <button type="submit">Submit</button>
                </form>
                <br>
                <table>
                <tr>
                    <th>Name</th>
                    <th>URL</th>
                    <th>Action</th>
                </tr>
                @foreach($data as $d)
                <tr>
                    <td>{{$d->category_name}}</td>
                    <td>{{$d->category_url}}</td>
                    <td><a><button type="button">edit</button></td>
                </tr>
                @endforeach
                </table>
            </main>
        </div>
    </body>
</html>
